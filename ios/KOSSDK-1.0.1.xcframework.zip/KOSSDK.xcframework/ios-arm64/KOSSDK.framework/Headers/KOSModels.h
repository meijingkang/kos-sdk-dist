// 工程: ios_wrapper
// 路径: ios_wrapper/Sources/KOSModels.h
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 宿主登录用户。token 只在包装层内存中使用，不会传给 Flutter，也不落盘。
@interface KOSUserInfo : NSObject <NSCopying>

@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy, nullable) NSString *token;
@property (nonatomic, copy, nullable) NSString *name;
@property (nonatomic, copy, nullable) NSString *mobile;
@property (nonatomic, copy, nullable) NSString *avatarURL;
@property (nonatomic, copy, nullable) NSString *dealerCode;
@property (nonatomic, copy, nullable) NSDictionary<NSString *, id> *extra;

- (instancetype)initWithUserId:(NSString *)userId NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

@end

typedef NS_ENUM(NSInteger, KOSShareScene) {
    KOSShareSceneSession = 0,
    KOSShareSceneTimeline = 1,
};

typedef NS_ENUM(NSInteger, KOSShareType) {
    KOSShareTypeWebpage = 0,
    KOSShareTypeImage = 1,
    KOSShareTypeText = 2,
    KOSShareTypeMiniProgram = 3,
};

/**
 * 分享内容由 SDK 组装后交给宿主。
 *
 * 图片不传二进制，只传 SDK 写好的临时文件绝对路径；宿主读取后自行转成微信 SDK 需要的
 * 数据类型。SDK 会在分享完成或超时后清理临时文件。
 */
@interface KOSShareInfo : NSObject

@property (nonatomic, assign) KOSShareType type;
@property (nonatomic, assign) KOSShareScene scene;
@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, copy, nullable) NSString *desc;
@property (nonatomic, copy, nullable) NSString *webpageURL;
@property (nonatomic, copy, nullable) NSString *thumbFilePath;
@property (nonatomic, copy, nullable) NSString *imageFilePath;
@property (nonatomic, copy, nullable) NSString *miniProgramId;
@property (nonatomic, copy, nullable) NSString *miniProgramPath;

@end

typedef NS_ENUM(NSInteger, KOSShareResult) {
    KOSShareResultSuccess = 0,
    KOSShareResultCancelled = 1,
    KOSShareResultFailed = 2,
    KOSShareResultNotInstalled = 3,
    KOSShareResultNotSupported = 4,
};

NS_ASSUME_NONNULL_END
