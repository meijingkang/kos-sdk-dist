// 工程: ios_wrapper
// 路径: ios_wrapper/Sources/KOSSDKDelegate.h
#import <Foundation/Foundation.h>
#import "KOSModels.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * 宿主实现的代理协议。
 *
 * 方向：
 * - 宿主 → SDK：KOSSDK 的 login / updateUserInfo / logout 类方法
 * - SDK → 宿主：本协议的 requestUserInfo / shareToWeChat / userInfoExpired
 *
 * 线程：SDK 保证所有方法在主线程调用。completion 可以由宿主在任意线程调用，SDK 会切回
 * 主线程；每次请求的 completion 必须且只能调用一次，SDK 侧有 10 秒超时。
 *
 * 生命周期：KOSSDK.delegate 是 weak，宿主必须用 Application/AppDelegate 级单例持有
 * 实现对象，不能传某个页面控制器。
 */
@protocol KOSSDKDelegate <NSObject>

@required
/// 场景 2：SDK 主动拉取当前用户；未登录回传 nil。
- (void)kosSDKRequestUserInfoWithCompletion:
    (void (^)(KOSUserInfo * _Nullable userInfo))completion;

@optional
/// 场景 3：SDK 请求宿主用自己的微信 SDK 发起分享。
- (void)kosSDKShareToWeChat:(KOSShareInfo *)shareInfo
                 completion:(void (^)(KOSShareResult result, NSString * _Nullable message))completion;

/// 场景 2 的兜底：KOS 会话失效，宿主续期后回传新用户；回传 nil 表示随后会 logout。
- (void)kosSDKUserInfoDidExpireWithCompletion:
    (void (^)(KOSUserInfo * _Nullable userInfo))completion;

/// 通用事件出口（埋点、打开宿主页面等）。
- (void)kosSDKDidReceiveEvent:(NSString *)event
                       params:(nullable NSDictionary<NSString *, id> *)params;

/// SDK 内部错误。
- (void)kosSDKDidReceiveErrorCode:(NSInteger)code message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
