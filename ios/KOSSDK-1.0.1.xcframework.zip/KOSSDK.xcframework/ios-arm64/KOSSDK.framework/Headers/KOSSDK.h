// 工程: ios_wrapper
// 路径: ios_wrapper/Sources/KOSSDK.h
#import <UIKit/UIKit.h>
#import "KOSSDKDelegate.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, KOSSDKErrorCode) {
    KOSSDKErrorInvalidArgument = 1001,
    KOSSDKErrorConfigUnavailable = 1002,
    KOSSDKErrorEngineNotInitialized = 1003,
    KOSSDKErrorCallbackError = 1004,
    KOSSDKErrorEngineReleased = 1005,
    KOSSDKErrorUserInfoTimeout = 1006,
    KOSSDKErrorShareTimeout = 1007,
    KOSSDKErrorDelegateNotSet = 1008,
    KOSSDKErrorShareNotSupported = 1009,
    KOSSDKErrorInternal = 1099,
};

/// KOS SDK 唯一对外入口。
@interface KOSSDK : NSObject

/// 宿主持有实现对象；SDK 弱引用。必须在 setup 之前或通过 setup 的 delegate 参数设置。
@property (class, nonatomic, weak, nullable) id<KOSSDKDelegate> delegate;

/// App 启动时调用一次。delegate 与初始化一起传入，避免空 delegate 时序窗口。
+ (void)setupWithAppKey:(NSString *)appKey
            environment:(NSInteger)environment
               delegate:(id<KOSSDKDelegate>)delegate
    NS_SWIFT_NAME(setup(appKey:environment:delegate:));

/// 场景 5：宿主登录成功（含冷启动时已是登录态）。
+ (void)loginWithUserInfo:(KOSUserInfo *)userInfo
    NS_SWIFT_NAME(login(userInfo:));

/// 场景 1：同一用户的信息变化（token 续期、改名、切换门店等）。
+ (void)updateUserInfo:(KOSUserInfo *)userInfo
    NS_SWIFT_NAME(updateUserInfo(userInfo:));

/// 场景 4：退出登录。清空用户、通知 Flutter，并关闭 SDK 创建的页面。
+ (void)logout;

/// 创建 KOS 页面，由宿主自己 push / present。
+ (nullable UIViewController *)viewControllerForPage:(NSString *)page
                                     params:(nullable NSDictionary<NSString *, id> *)params
    NS_SWIFT_NAME(viewController(page:params:));

+ (NSString *)sdkVersion;

@end

NS_ASSUME_NONNULL_END
